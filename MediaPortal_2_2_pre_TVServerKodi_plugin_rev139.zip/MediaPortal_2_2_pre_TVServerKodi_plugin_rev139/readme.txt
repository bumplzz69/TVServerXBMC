TVServerKodi plugin for MediaPortal 2.2 pre TVServer 1.20

To install (requires Administrator permissions):
- Stop the "Mediaportal 2 Server" service
- Delete any exising TVServerKodi.dll from:
  C:\Program Files (x86)\Team Mediaportal\MP2-Server\Plugins\SlimTv.Service3\Plugins
- Copy the TVServerKodi.dll from the Release folder to:
  C:\Program Files (x86)\Team Mediaportal\MP2-Server\Plugins\SlimTv.Service3\Plugins
- Start the "Mediaportal 2 Server" service
- Enable the plugin in the "Mediaportal 2 TV Configuration" tool
- Restart the "Mediaportal 2 Server" service

For help:
  http://forum.kodi.tv/forumdisplay.php?fid=171

Marcel Groothuis
Author Mediaportal PVR addon for XBMC/Kodi